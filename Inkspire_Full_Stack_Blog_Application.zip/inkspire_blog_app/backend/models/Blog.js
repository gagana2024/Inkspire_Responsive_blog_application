const mongoose=require("mongoose");
const blogSchema=new mongoose.Schema({
 title:{type:String,required:true,trim:true,maxlength:120},
 content:{type:String,required:true},
 category:{type:String,default:"STORY"},
 author:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true}
},{timestamps:true});
module.exports=mongoose.model("Blog",blogSchema);