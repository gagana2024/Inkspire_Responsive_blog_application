# Backend setup

Requirements: Node.js LTS and MongoDB Community Server or MongoDB Atlas.

```bash
npm install
```
Copy `.env.example` to `.env`. Configure:
- `MONGO_URI`: local default is `mongodb://127.0.0.1:27017/inkspire`; use your Atlas connection string if using Atlas.
- `JWT_SECRET`: replace with a long random secret.

Start the backend:
```bash
npm run dev
```
API base URL: `http://localhost:5000`

## Routes
- `POST /api/auth/register` — JSON `{ "name":"Gagana", "email":"gagana@example.com", "password":"secret123" }`
- `POST /api/auth/login` — JSON `{ "email":"gagana@example.com", "password":"secret123" }`
- `GET /api/blogs` — returns published blog posts
- `POST /api/blogs` — authenticated; JSON `{ "title":"My First Story", "content":"Hello world", "category":"JOURNAL" }`; include `Authorization: Bearer YOUR_TOKEN`.

The frontend's `app.js` calls this API at `http://localhost:5000/api`. Keep the backend running while using Live Server.
