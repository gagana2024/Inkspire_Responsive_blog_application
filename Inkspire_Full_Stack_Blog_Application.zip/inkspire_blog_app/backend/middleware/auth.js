const jwt=require("jsonwebtoken");
module.exports=(req,res,next)=>{
 const h=req.headers.authorization||"",token=h.startsWith("Bearer ")?h.slice(7):null;
 if(!token)return res.status(401).json({message:"Please log in first."});
 try{req.user=jwt.verify(token,process.env.JWT_SECRET);next();}
 catch(e){return res.status(401).json({message:"Invalid or expired token."});}
};