const router=require("express").Router();
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const User=require("../models/User");
const tokenFor=u=>jwt.sign({id:u._id,email:u.email},process.env.JWT_SECRET,{expiresIn:"7d"});
router.post("/register",async(req,res)=>{
 try{
  const {name,email,password}=req.body;
  if(!name||!email||!password)return res.status(400).json({message:"Name, email and password are required."});
  if(password.length<6)return res.status(400).json({message:"Password must be at least 6 characters."});
  if(await User.findOne({email:email.toLowerCase()}))return res.status(409).json({message:"Email is already registered."});
  const user=await User.create({name,email,password:await bcrypt.hash(password,12)});
  res.status(201).json({message:"Account created.",token:tokenFor(user),user:{id:user._id,name:user.name,email:user.email}});
 }catch(e){res.status(500).json({message:"Registration failed."});}
});
router.post("/login",async(req,res)=>{
 try{
  const {email,password}=req.body;
  if(!email||!password)return res.status(400).json({message:"Email and password are required."});
  const user=await User.findOne({email:email.toLowerCase()});
  if(!user||!(await bcrypt.compare(password,user.password)))return res.status(401).json({message:"Incorrect email or password."});
  res.json({message:"Login successful.",token:tokenFor(user),user:{id:user._id,name:user.name,email:user.email}});
 }catch(e){res.status(500).json({message:"Login failed."});}
});
module.exports=router;