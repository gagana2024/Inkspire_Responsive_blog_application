const router=require("express").Router();
const Blog=require("../models/Blog");
const auth=require("../middleware/auth");
router.get("/",async(req,res)=>{
 try{const blogs=await Blog.find().populate("author","name").sort({createdAt:-1});res.json({blogs});}
 catch(e){res.status(500).json({message:"Could not fetch blogs."});}
});
router.post("/",auth,async(req,res)=>{
 try{
  const {title,content,category}=req.body;
  if(!title||!content)return res.status(400).json({message:"Title and content are required."});
  const blog=await Blog.create({title,content,category,author:req.user.id});
  res.status(201).json({message:"Blog published successfully.",blog});
 }catch(e){res.status(500).json({message:"Could not publish blog."});}
});
module.exports=router;