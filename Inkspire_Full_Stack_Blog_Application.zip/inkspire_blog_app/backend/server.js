const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");
require("dotenv").config();
const app=express();
app.use(cors());
app.use(express.json());
app.get("/",(req,res)=>res.json({message:"Inkspire API is running"}));
app.use("/api/auth",require("./routes/authRoutes"));
app.use("/api/blogs",require("./routes/blogRoutes"));
const PORT=process.env.PORT||5000;
mongoose.connect(process.env.MONGO_URI).then(()=>{
 console.log("MongoDB connected successfully");
 app.listen(PORT,()=>console.log(`API running at http://localhost:${PORT}`));
}).catch(err=>{console.error("MongoDB connection failed:",err.message);process.exit(1);});